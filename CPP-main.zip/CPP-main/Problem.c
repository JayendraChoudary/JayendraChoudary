#include<stdio.h>
main()
{
	int a=25,b=2,e=0,f=0,g=0,h=0;
	float c=35.0,d=2.0;
	e=6+a/5*b;
	printf("the output for solution 1 is%d\n",e);
	f=((a/b)*b);
	printf("the output for solution 2 is%d\n",f);
	g=c/d*d;
	printf("the output for solution 3 is%d\n",g);
	h=-a;
	printf("the output for solution 4 is%d\n",h);
	
}
