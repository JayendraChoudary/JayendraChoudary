#include<stdio.h>
main()
{
	int a,b,c=0,d=0,e=0,f=0,g=0;
	printf("Enter the Value of a");
	scanf("%d",&a);
	printf("Enter the Value of b");
	scanf("%d",&b);
	c=a+b;
	printf("The Sum Two values Entered in A and B Are%d\n",c);
	d=a-b;
	printf("The Difference Of two Values Enterd Are%d\n",d);
	e=a*b;
	printf("The product of two Numbers=%d\n",e);
	f=a/b;
	printf("The Division of the two numbers =%d\n",f);
	g=a%b;
	printf("The mod of two numbers=%d",g);
	
	
}
