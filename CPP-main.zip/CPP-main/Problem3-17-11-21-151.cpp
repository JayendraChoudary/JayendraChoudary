#include<stdio.h>
main()
{

int i=42;
printf("i value is %d",i++);
i=42;
printf("i value is %d",++i);
i=42;
printf("i value is %d",--i);
i=42;
printf("i value is %d",i--);

}

