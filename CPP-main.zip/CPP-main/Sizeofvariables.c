#include<stdio.h>
main()
{
	int a=0,b=0,c=0,d=0,e=0;
	a=sizeof (int);
	printf("The size of int =%d\n",a);
	b=sizeof (float);
	printf("The size of Float=%d\n",b);
	c=sizeof (char);
	printf("the size of Char=%d\n",c);
	d=sizeof (double);
	printf("The size of Double=%d\n",d);
	e=sizeof (long);
	printf("The size of long=%d",e);
}
