#include<stdio.h>
main()
{
int a,b,c;
c=a+b;
printf("a value is %d",a);
}
