#include<stdio.h>
main (
{int a,b,c;
print f ("enter the two numbers")
scan f ( "%d %d",&a,&b,)
sum=a+b;
);
})>
