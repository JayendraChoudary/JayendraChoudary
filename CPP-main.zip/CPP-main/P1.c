/*
#include<stdio.h>
#include<conio.h>
int main()
{
	int a,b,c;
	printf("enter the values of a,b,c");
	scanf("%d%d%d",&a,&b,&c);
	printf("value a=%d,b=%d,c=%d",a,b,c);
	return 0;
}
*/

/* second program 
#include<stdio.h>
#include<conio.h>
void main()
{
		char ch ='#';
		printf("######");
		printf("\n######");
		printf("\n######");
		printf("\n######");
		return 0;
}
*/
