#include<stdio.h>
main (
{print f ("welcome to c")
})>
