#include<stdio.h>
main (
{print f ("abhitha,anitha,bhavana,mounika,mourya")
})>
