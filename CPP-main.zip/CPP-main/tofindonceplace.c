#include<stdio.h>
main()
{
	int x,y=0;
	printf("Enter the value of x");
	scanf("%d",&x);
	y=x%10;
	printf("The Once Place of y=%d",y);
}
