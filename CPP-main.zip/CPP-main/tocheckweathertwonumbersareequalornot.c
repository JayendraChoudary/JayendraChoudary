#include<stdio.h>
main()
{
	int a,b;
	printf("Enter The Value of A");
	scanf("%d",&a);
	printf("Enter The Value of B");
	scanf("%d",&b);
	if (a==b)
	{
	printf("Entered Number is Equal%d%d\n",a,b);
	}
	else 
	{
	printf("Entered Number is Not Equal%d%d\n",a,b);
	}
}

