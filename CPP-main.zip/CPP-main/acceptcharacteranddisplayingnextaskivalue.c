#include<stdio.h>
main()
{
	char A;
	printf("Enter a Character");
	A=getchar();
	
}
