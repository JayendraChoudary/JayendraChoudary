#include<stdio.h>
main()
{
	int a,b;
	printf("Enter The Value of A");
	scanf("%d",&a);
	if (a%2==0)
	{
	printf("Entered Number is Even%d\n",a);
	}
	else 
	{
	printf("Entered Number is Odd%d\n",a);
	}
}

