#include<stdio.h>
main()
{
	int a;
	printf("Enter the Value of A");
	scanf("%d",&a);
	if (a==0)
	{
		printf("Entered Number is a Zero%d\n",a);
	}
	else if(a>0)
	{
	printf("Enterd number is a positive number");
}
else
{
	printf("Entered Number is a Negative Number");
}
	
}
