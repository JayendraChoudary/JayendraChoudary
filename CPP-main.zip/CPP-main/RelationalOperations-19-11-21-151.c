#include<stdio.h>
main()
{
	printf("6>4 is evaluated value is%d\n",6>4);
	printf("6<4 is evaluated value is%d\n",6<4);
	printf("6==4 is evaluated value is%d\n",6==4);
	printf("6!=4 is evaluated value is%d\n",6!=4);
	printf("6>=4 is evaluated value is%d\n",6>=4);
	printf("6<=4 is evaluated value is%d",6<=4);
}
